## jQuery plugin carouselTicker

# carouselTicker v1.0.0

- Fully responsive - will adapt to any device
- Horizontal and vertical modes
- Full callback API and public methods
- Small file size
- Browser support: Firefox, Chrome, Safari, iOS, Android, IE7+
- Tons of configuration options

For complete documentation, tons of examples, and a good time, visit:

[http://yuriyberezovskiy.github.io/carouselTicker](http://yuriyberezovskiy.github.io/carouselTicker)

Written by: Yuriy Berezovskiy - [http://yuriyberezovskiy.github.io](http://yuriyberezovskiy.github.io)

### License

Released under the MIT license - http://opensource.org/licenses/MIT
